param(
    [Parameter(Mandatory = $true)][string[]]$InputPath,
    [Parameter(Mandatory = $true)][string]$OutputFile
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if (Test-Path -LiteralPath $OutputFile) { throw "Choose a new CSV path; refusing to overwrite $OutputFile" }
$rows = @(
    foreach ($path in $InputPath) {
        $settings = New-Object System.Xml.XmlReaderSettings
        $settings.DtdProcessing = [System.Xml.DtdProcessing]::Prohibit
        $settings.XmlResolver = $null
        $reader = [System.Xml.XmlReader]::Create((Resolve-Path -LiteralPath $path).ProviderPath, $settings)
        try {
            $document = New-Object System.Xml.XmlDocument
            $document.XmlResolver = $null
            $document.Load($reader)
            $namespaces = New-Object System.Xml.XmlNamespaceManager($document.NameTable)
            $namespaces.AddNamespace('t', 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010')
            $results = @($document.SelectNodes('/t:TestRun/t:Results/t:UnitTestResult', $namespaces))
            if ($results.Count -eq 0) { throw "No recognized test results in $path" }
            foreach ($result in $results) {
                $name = $result.GetAttribute('testName')
                $outcome = $result.GetAttribute('outcome')
                if ([string]::IsNullOrWhiteSpace($name) -or [string]::IsNullOrWhiteSpace($outcome)) { throw "Missing test name/outcome in $path" }
                $duration = [TimeSpan]::Zero
                $durationText = $result.GetAttribute('duration')
                if ($durationText -and -not [TimeSpan]::TryParse($durationText, [Globalization.CultureInfo]::InvariantCulture, [ref]$duration)) { throw "Invalid test duration in $path" }
                [pscustomobject]@{
                    test_name = $name
                    outcome = if ($outcome -eq 'NotExecuted') { 'Skipped' } else { $outcome }
                    duration_ms = $duration.TotalMilliseconds.ToString([Globalization.CultureInfo]::InvariantCulture)
                }
            }
        } finally { $reader.Dispose() }
    }
)
if ($rows.Count -eq 0) { throw 'No test results supplied.' }
$rows | Export-Csv -LiteralPath $OutputFile -NoTypeInformation -Encoding UTF8
