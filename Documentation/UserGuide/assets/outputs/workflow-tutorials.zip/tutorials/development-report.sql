-- Fictional, normalized build artifacts. Run against a NEW database.
BEGIN IMMEDIATE;
CREATE VIRTUAL TABLE temp.build_lines USING ParsingModule(
  'samples/tutorials/compiler-output.txt', '-i:TextLine');
CREATE TEMP TABLE raw_build_lines AS SELECT Text FROM build_lines;
CREATE TEMP TABLE diagnostic_lines AS
SELECT Text FROM raw_build_lines
WHERE RX_IS_MATCH(Text, '^.+\([0-9]+,[0-9]+\):[ ](warning|error)[ ][A-Za-z]+[0-9]+:');
CREATE TABLE compiler_diagnostics AS
SELECT DISTINCT
  RX_GET_GROUP_VALUE(Text, '^(?<path>.+)\([0-9]+,[0-9]+\):', 'path') AS path,
  CAST(RX_GET_GROUP_VALUE(Text, '^.+\((?<line>[0-9]+),[0-9]+\):', 'line') AS INTEGER) AS line,
  RX_GET_GROUP_VALUE(Text, '\):[ ](?<severity>warning|error)[ ]', 'severity') AS severity,
  RX_GET_GROUP_VALUE(Text, '\):[ ](?:warning|error)[ ](?<code>[A-Za-z]+[0-9]+):', 'code') AS code,
  Text AS original_text
FROM diagnostic_lines;
CREATE INDEX ix_diagnostics_path_line ON compiler_diagnostics(path, line);

CREATE VIRTUAL TABLE temp.tests_input USING ParsingModule(
  'samples/tutorials/test-results.csv', '-i:CSV');
CREATE TABLE test_results AS
SELECT test_name, outcome, CAST(duration_ms AS REAL) AS duration_ms FROM tests_input;

CREATE VIRTUAL TABLE temp.before_input USING ParsingModule(
  'samples/tutorials/files-before.csv', '-i:CSV');
CREATE VIRTUAL TABLE temp.after_input USING ParsingModule(
  'samples/tutorials/files-after.csv', '-i:CSV');
CREATE TABLE files_before AS SELECT * FROM before_input;
CREATE TABLE files_after AS SELECT * FROM after_input;
CREATE UNIQUE INDEX ix_files_before_path ON files_before(path);
CREATE UNIQUE INDEX ix_files_after_path ON files_after(path);
CREATE TABLE changed_files AS
SELECT a.path, CASE WHEN b.path IS NULL THEN 'Added' ELSE 'Modified' END AS change
FROM files_after a LEFT JOIN files_before b ON b.path = a.path
WHERE b.path IS NULL OR a.sha256 <> b.sha256
UNION ALL
SELECT b.path, 'Deleted' FROM files_before b
LEFT JOIN files_after a ON a.path = b.path WHERE a.path IS NULL;

CREATE VIRTUAL TABLE temp.refs_input USING ParsingModule(
  'samples/tutorials/assembly-references.csv', '-i:CSV');
CREATE VIRTUAL TABLE temp.allowed_input USING ParsingModule(
  'samples/tutorials/allowed-assemblies.csv', '-i:CSV');
CREATE TABLE assembly_refs AS SELECT * FROM refs_input;
CREATE TABLE allowed_assemblies AS SELECT * FROM allowed_input;
CREATE TABLE unexpected_references AS
SELECT r.* FROM assembly_refs r
WHERE NOT EXISTS (
  SELECT 1 FROM allowed_assemblies a
  WHERE a.AssemblyName = r.AssemblyName COLLATE NOCASE
    AND a.Version = r.Version
    AND coalesce(a.PublicKeyToken, '') = coalesce(r.PublicKeyToken, '') COLLATE NOCASE
);
CREATE TABLE gate_summary AS
SELECT (SELECT COUNT(*) FROM compiler_diagnostics WHERE severity = 'error') AS compiler_errors,
       (SELECT COUNT(*) FROM test_results WHERE outcome = 'Failed') AS failed_tests,
       (SELECT COUNT(*) FROM unexpected_references) AS unexpected_references;
COMMIT;

SELECT * FROM gate_summary;
