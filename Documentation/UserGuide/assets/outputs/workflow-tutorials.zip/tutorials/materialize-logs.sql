-- Run from the extracted ULP directory, against a NEW database.
-- Only ordinary tables are persistent; no consumer needs ParsingModule.
BEGIN IMMEDIATE;
CREATE VIRTUAL TABLE temp.request_input USING ParsingModule(
  'samples/tutorials/log-requests.csv', '-i:CSV');

CREATE TABLE log_requests (
  request_id INTEGER PRIMARY KEY,
  timestamp_utc TEXT NOT NULL,
  route TEXT NOT NULL CHECK(length(route) > 0),
  status INTEGER NOT NULL CHECK(status BETWEEN 100 AND 599),
  duration_ms REAL NOT NULL CHECK(duration_ms >= 0)
);
INSERT INTO log_requests(timestamp_utc, route, status, duration_ms)
SELECT strftime('%Y-%m-%dT%H:%M:%SZ', timestamp_utc), route,
       CAST(status AS INTEGER), CAST(duration_ms AS REAL)
FROM request_input;

CREATE INDEX ix_log_requests_route_time ON log_requests(route, timestamp_utc);
CREATE TABLE log_hourly AS
SELECT strftime('%Y-%m-%dT%H:00:00Z', timestamp_utc) AS hour_utc,
       route, COUNT(*) AS requests,
       SUM(CASE WHEN status >= 500 THEN 1 ELSE 0 END) AS errors,
       SUM(duration_ms) AS total_duration_ms,
       ROUND(AVG(duration_ms), 2) AS mean_ms,
       ROUND(PERCENTILE_CONT(duration_ms, 0.95), 2) AS p95_ms
FROM log_requests
GROUP BY hour_utc, route;
CREATE UNIQUE INDEX ix_log_hourly_hour_route ON log_hourly(hour_utc, route);
CREATE TABLE snapshot_info AS
SELECT 'log-dashboard-v1' AS schema_id,
       strftime('%Y-%m-%dT%H:%M:%SZ', 'now') AS created_utc,
       (SELECT COUNT(*) FROM log_requests) AS input_rows;
DROP TABLE temp.request_input;
ANALYZE;
COMMIT;

SELECT hour_utc, route, requests, errors, mean_ms, p95_ms
FROM log_hourly ORDER BY hour_utc, route;
