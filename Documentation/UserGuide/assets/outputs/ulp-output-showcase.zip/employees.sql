SELECT employee_id, employee_name, department_id FROM employees WHERE lower(active)='true' ORDER BY employee_id LIMIT 3;
