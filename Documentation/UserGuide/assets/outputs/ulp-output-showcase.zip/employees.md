| employee_id | employee_name | department_id |
| :--- | :--- | :--- |
| 1 | Ada | 10 |
| 2 | Grace | 10 |
| 3 | Linus | 20 |


